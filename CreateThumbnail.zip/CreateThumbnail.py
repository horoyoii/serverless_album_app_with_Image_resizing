from __future__ import print_function
import boto3
import os
import sys
import uuid
from PIL import Image
import PIL.Image
     
s3_client = boto3.client('s3')
     

# s3_client = boto3.client('s3')
     
# def resize_image(image_path, resized_path):
#     with Image.open(image_path) as image:
#         image.thumbnail(tuple(x / 2 for x in image.size))
#         image.save(resized_path)
     
# def handler(event, context):
#     for record in event['Records']:
#         bucket = record['s3']['bucket']['name']
#         key = record['s3']['object']['key'] 
#         download_path = '/tmp/{}{}'.format(uuid.uuid4(), key)
#         upload_path = '/tmp/resized-{}'.format(key)
        
#         s3_client.download_file(bucket, key, download_path)
#         resize_image(download_path, upload_path)
#         s3_client.upload_file(upload_path, '{}resized'.format(bucket), key)


## Example of file I/O

# s3_client = boto3.client('s3')
# open('hello.txt').write('Hello, world!')

# # Upload the file to S3
# s3_client.upload_file('hello.txt', 'MyBucket', 'hello-remote.txt')

# # Download the file from S3
# s3_client.download_file('MyBucket', 'hello-remote.txt', 'hello2.txt')
# print(open('hello2.txt').read())

def resize_image(image_path, resized_path):
	with Image.open(image_path) as image:
		size = (200, 200)
		image.thumbnail(size)
		image.save(resized_path)

s3 = boto3.resource('s3')


def handler(event, context):
	for record in event['Records']:
		bucket = record['s3']['bucket']['name']
		key = record['s3']['object']['key'] 
		print("Bucket is : ", bucket)
		print("Key is : ", key)

		### Get Image from S3
		#s3(bucket).download_file(key, 'my_local_image.jpg')
		image = s3.meta.client.download_file(bucket, key, '/tmp/1.jpg')

		reside_local_path = '/tmp/2.jpg'

		s3_client.upload_file('/tmp/1.jpg', bucket, 'sub/result.jpg')
		
		resize_image('/tmp/1.jpg', reside_local_path)

		s3_client.upload_file(reside_local_path, bucket, 'w2/result.jpg')


		print("Done")




		image = s3.meta.client.download_file(bucket, '/tmp/su.jpg', '/tmp/1.jpg')
		print("Done2 ")



		download_path = '/tmp/{}{}'.format(uuid.uuid4(), key)
		lambda_path = '/tmp/{}'.format(key)
		print("lambda_path is : ", lambda_path)

		upload_path = '/tmp/resized-{}'.format(key)
        
		print("resized... ")

		s3_client.download_file(bucket, key, lambda_path)

		resize_image(lambda_path, upload_path)
		
		s3_client.upload_file(upload_path, '{}resized'.format(bucket), key)


def t_handler(event, context):
	for record in event['Records']:
		bucket = record['s3']['bucket']['name']
		print("Log bucket name:", bucket)
		
		key = record['s3']['object']['key'] 
		
		print("Log key name:", key)
		download_path = '/tmp/{}{}'.format(uuid.uuid4(), key)
		
		#download_path = '/'+key
		print("Log download_path name:", download_path)
		
		upload_path = '/tmp/resized-{}'.format(key)
		print("Log upload_path name:", upload_path)
			
		# create source directory
		directory = os.path.dirname(download_path)
		print("Log directory name :", directory)

		if not os.path.exists(directory):
			print("Log Make Dir ")
			os.makedirs(directory)

		if os.path.exists(directory):
			print("Log Dir is made")

		#create target directory
		targetdirectory = os.path.dirname(upload_path)
		print("Log targetdirectory name :", targetdirectory)

		if not os.path.exists(targetdirectory):
			os.makedirs(targetdirectory)

		s3_client.download_file(bucket, key, download_path)
		resize_image(download_path, upload_path)
		s3_client.upload_file(upload_path, '{}'.format(bucket), key)
	
	print("end")